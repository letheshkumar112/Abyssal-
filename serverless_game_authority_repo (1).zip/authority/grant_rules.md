Purchase Grant Rules:
1. Token from Store SDK
2. PurchaseState == PURCHASED
3. Not previously acknowledged
4. Grant once
5. Acknowledge immediately
