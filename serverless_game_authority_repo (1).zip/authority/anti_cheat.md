Deterministic authority checks.
No server. No human moderation.
