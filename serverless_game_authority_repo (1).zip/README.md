# Serverless Store-Authoritative Game Authority

This repository contains **static authority definitions only**.
- No billing execution
- No secrets
- Store SDK remains the only payment authority

Billing libraries live **inside the app**, not here.
